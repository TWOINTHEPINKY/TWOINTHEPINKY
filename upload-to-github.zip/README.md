<!-- ═══════════════════════════════════════════════════════════════════════════
     🚀 ШАБЛОН КРУТОГО GITHUB PROFILE README
     ═══════════════════════════════════════════════════════════════════════════
     КАК ИСПОЛЬЗОВАТЬ:
     1. Создай репозиторий с именем, СОВПАДАЮЩИМ с твоим юзернеймом на GitHub
        (например, юзернейм "alexdev" → репозиторий "alexdev")
     2. Скопируй этот файл как README.md в корень того репозитория
     3. Замени ВСЕ заглушки (команда для Linux/Mac/Git Bash):
        sed -i 's/YOUR-USERNAME/твой_юзернейм/g; s/YOUR_NAME/Твоё Имя/g; s/YOUR_SPOTIFY_ID/твой_spotify_id/g' README.md
     4. Удали/закомментируй секции, которые не нужны
     5. Всё, что в <!-- таких комментариях --> — на GitHub НЕ отображается,
        поэтому подсказки можно смело оставлять в файле
     ═══════════════════════════════════════════════════════════════════════ -->

<div align="center">

<!-- ═══ АНИМИРОВАННЫЙ БАННЕР-ШАПКА (capsule-render, генерирует SVG с волной) ═══
     Сменить цвет: color=gradient | 0:88:ff-ff00cc | random | 0a66c2-ffffff
     Типы: waving | transparent | soft | cut | rounded | rect
     Конструктор: https://capsule-render.vercel.app -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=2,11,30&height=280&section=header&text=YOUR_NAME&fontSize=60&fontColor=ffffff&animation=fadeIn&fontAlignY=36&desc=Full-Stack%20Developer%20%7C%20Open%20Source%20Enthusiast&descSize=18&descAlignY=58" width="100%" alt="Header banner"/>

<!-- ═══ ПЕЧАТАЮЩИЙСЯ ТЕКСТ (typewriter) ═══
     Строки через %20%20|%20 (это " | " с URL-кодированием пробелов)
     Конструктор: https://github.com/DenverCoder1/readme-typing-svg -->
<a href="https://github.com/YOUR-USERNAME">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=26&duration=3000&pause=800&color=00D4FF&center=true&vCenter=true&width=650&lines=%F0%9F%91%8B+Hi%2C+I'm+YOUR_NAME;%F0%9F%92%BB+I+build+cool+things+for+the+web;%F0%9F%8E%AE+Gamer+%26+Coffee+Lover+%E2%98%95;%F0%9F%8C%B1+Currently+learning+Rust+%26+Go" alt="Typing SVG"/>
</a>

<br/>

<!-- ═══ СЧЁТЧИКИ И КНОПКИ-БЕЙДЖИ ═══
     komarev.com — счётчик посетителей профиля
     shields.io/github/followers — кнопка "Follow" (style=social) -->
<img src="https://komarev.com/ghpvc/?username=YOUR-USERNAME&style=for-the-badge&color=blueviolet&label=👀+PROFILE+VIEWS" alt="Profile views"/>
<a href="https://github.com/YOUR-USERNAME?tab=followers">
  <img src="https://img.shields.io/github/followers/YOUR-USERNAME?style=social" alt="Followers"/>
</a>
<a href="https://github.com/YOUR-USERNAME?tab=repositories">
  <img src="https://img.shields.io/badge/📦-Public%20Repos-blue?style=for-the-badge&logo=github&logoColor=white" alt="Repos"/>
</a>

</div>

<!-- ═══ ✂️ АНИМИРОВАННЫЕ РАЗДЕЛИТЕЛИ (вместо чёрных ---) ═══
     Все варианты лежат в ./assets/dividers/ — просто меняй имя файла в src:
       neon-slide.svg            — неоновая комета, бегущая по линии
       rainbow-flow.svg          — радужная переливающаяся линия
       wave-dash.svg             — бегущая пунктирная волна
       pulse-dots.svg            — волна из пульсирующих точек
       divider-classic-blue.gif  — классическая синяя GIF-линия
     Цвет меняется в SVG поиском-заменой #00d4ff / #7b2ff7 на свои.
     Ещё источники: GUIDE_RU.md, раздел 11 -->
<div align="center">
  <img src="./assets/dividers/neon-slide.svg" width="100%" height="8" alt="──────────"/>
</div>

<!-- ═══════════════════ 🧑‍💻 ABOUT ME ═══════════════════ -->
## <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMW01a3g5dWU5Z3U5bXU0d3k4bXVhOW5nOW5nOW5nOW5nOW5nJmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1z/du3J3cDWLhUrTUDQIf/giphy.gif" width="32" height="32"/> About Me

<table border="0">
<tr>
<td width="60%" valign="top">

- 🔭 Currently working on: **My Awesome Project**
- 🌱 Learning: **Rust, System Design**
- 💬 Ask me about: **React, Node.js, Python**
- 📫 How to reach me: **your@email.com**
- ⚡ Fun fact: **I debug with printf, not breakpoints**
- 🎯 2026 Goal: **Ship 12 open-source projects**

</td>
<td width="40%" valign="top" align="center">

<!-- ТВОЁ ФОТО / АВАТАР. Варианты:
     1. Загрузи файл в папку assets/ репозитория и укажи путь ./assets/me.png
     2. Внешняя ссылка (Unsplash, свой сайт)
     Круглая картинка делается CSS прямо тут — GitHub это разрешает в img -->
<img src="https://avatars.githubusercontent.com/u/583231?v=4" width="220" height="220" style="border-radius: 50%; border: 4px solid #00D4FF;" alt="My photo"/>

<br/>

<!-- Анимированный GIF под фото — просто для красоты.
     Ссылку на GIF берёшь с Giphy (см. гайд, раздел GIF) -->
<img src="https://media.giphy.com/media/qgQUggAC3Pfv687qPC/giphy.gif" width="220" alt="Coding gif"/>

</td>
</tr>
</table>

<!-- ✂️ разделитель: wave-dash.svg -->
<div align="center">
  <img src="./assets/dividers/wave-dash.svg" width="100%" height="10" alt="──────────"/>
</div>

<!-- ═══════════════════ 🛠 TECH STACK ═══════════════════ -->
## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="32" height="32"/> Tech Stack

<!-- ═══ ✨ ВАРИАНТ 0: АНИМИРОВАННЫЕ SVG-ИКОНКИ (собственный локальный набор) ═══
     Папка ./assets/icons-animated/icons/ — 29 иконок с анимацией и неоновым
     ореолом: js, ts, react (крутится!), vue, nodejs, python, go, rust, java,
     spring, php, docker, k8s, postgres, mongo, redis, mysql, nginx, git, github,
     linux, html5, css3, tailwind, vscode, figma, aws, discord, telegram.
     Не зависят от чужих серверов — не отвалятся никогда.
     ➕ Добавить свою: впиши slug с https://simpleicons.org в список ICONS файла
     assets/icons-animated/build_icons.py и запусти:  python3 build_icons.py -->
<div align="center">
  <img src="./assets/icons-animated/icons/javascript.svg" width="48" height="48" alt="javascript" title="javascript"/>
  <img src="./assets/icons-animated/icons/typescript.svg" width="48" height="48" alt="typescript" title="typescript"/>
  <img src="./assets/icons-animated/icons/react.svg" width="48" height="48" alt="react" title="react"/>
  <img src="./assets/icons-animated/icons/vue.svg" width="48" height="48" alt="vue" title="vue"/>
  <img src="./assets/icons-animated/icons/nodejs.svg" width="48" height="48" alt="nodejs" title="nodejs"/>
  <img src="./assets/icons-animated/icons/python.svg" width="48" height="48" alt="python" title="python"/>
  <img src="./assets/icons-animated/icons/go.svg" width="48" height="48" alt="go" title="go"/>
  <img src="./assets/icons-animated/icons/docker.svg" width="48" height="48" alt="docker" title="docker"/>
  <img src="./assets/icons-animated/icons/kubernetes.svg" width="48" height="48" alt="kubernetes" title="kubernetes"/>
  <img src="./assets/icons-animated/icons/postgresql.svg" width="48" height="48" alt="postgresql" title="postgresql"/>
  <img src="./assets/icons-animated/icons/mongodb.svg" width="48" height="48" alt="mongodb" title="mongodb"/>
  <img src="./assets/icons-animated/icons/redis.svg" width="48" height="48" alt="redis" title="redis"/>
  <img src="./assets/icons-animated/icons/git.svg" width="48" height="48" alt="git" title="git"/>
  <img src="./assets/icons-animated/icons/github.svg" width="48" height="48" alt="github" title="github"/>
  <img src="./assets/icons-animated/icons/linux.svg" width="48" height="48" alt="linux" title="linux"/>
  <img src="./assets/icons-animated/icons/html5.svg" width="48" height="48" alt="html5" title="html5"/>
  <img src="./assets/icons-animated/icons/css3.svg" width="48" height="48" alt="css3" title="css3"/>
  <img src="./assets/icons-animated/icons/tailwind.svg" width="48" height="48" alt="tailwind" title="tailwind"/>
  <img src="./assets/icons-animated/icons/vscode.svg" width="48" height="48" alt="vscode" title="vscode"/>
  <img src="./assets/icons-animated/icons/aws.svg" width="48" height="48" alt="aws" title="aws"/>
</div>

<br/>

<!-- GIF-варианты анимированных логотипов ищи в коллекции:
     https://github.com/Anmol-Baranwal/Cool-GIFs-For-GitHub → секция "Moving Logos"
     Вставляются так же: <img src="URL.gif" width="50"/> -->

<!-- ═══ ВАРИАНТ 1: skillicons.dev — красивые готовые иконки (SVG)
     Полный список: https://skillicons.dev  (параметр i= через запятую)
     theme=dark | light ; perline=10 — иконок в ряду -->
<div align="center">
  <img src="https://skillicons.dev/icons?i=html,css,js,ts,react,vue,nodejs,express,nextjs&theme=dark&perline=9" alt="Frontend"/>
  <br/>
  <img src="https://skillicons.dev/icons?i=python,django,fastapi,go,rust,java,spring&theme=dark&perline=9" alt="Backend"/>
  <br/>
  <img src="https://skillicons.dev/icons?i=postgres,mysql,mongodb,redis,docker,kubernetes,aws,linux,git&theme=dark&perline=9" alt="DevOps"/>
</div>

<br/>

<!-- ═══ ВАРИАНТ 2: shields.io бейджи с логотипами simple-icons
     Названия логотипов: https://simpleicons.org (наведи на иконку — получишь slug)
     Конструктор бейджа: https://shields.io/badges/custom-badge -->
<div align="center">
  <a href="#"><img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JS"/></a>
  <a href="#"><img src="https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TS"/></a>
  <a href="#"><img src="https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React"/></a>
  <a href="#"><img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python"/></a>
  <a href="#"><img src="https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white" alt="Docker"/></a>
</div>

<!-- ✂️ разделитель: rainbow-flow.svg -->
<div align="center">
  <img src="./assets/dividers/rainbow-flow.svg" width="100%" height="8" alt="──────────"/>
</div>

<!-- ═══════════════════ 🔗 SOCIALS (КЛИКАБЕЛЬНЫЕ КНОПКИ) ═══════════════════ -->
## <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="32" height="32"/> Connect With Me

<div align="center">

<a href="https://t.me/YOUR-USERNAME"><img src="https://img.shields.io/badge/Telegram-26A5E4?style=for-the-badge&logo=telegram&logoColor=white" alt="Telegram"/></a>
<a href="https://discord.com/users/YOUR-DISCORD-ID"><img src="https://img.shields.io/badge/Discord-5865F2?style=for-the-badge&logo=discord&logoColor=white" alt="Discord"/></a>
<a href="https://linkedin.com/in/YOUR-USERNAME"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"/></a>
<a href="mailto:your@email.com"><img src="https://img.shields.io/badge/Gmail-EA4335?style=for-the-badge&logo=gmail&logoColor=white" alt="Gmail"/></a>
<a href="https://your-portfolio.dev"><img src="https://img.shields.io/badge/Portfolio-FF7139?style=for-the-badge&logo=firefox&logoColor=white" alt="Portfolio"/></a>
<a href="https://codeforces.com/profile/YOUR-USERNAME"><img src="https://img.shields.io/badge/Codeforces-1F8ACB?style=for-the-badge&logo=codeforces&logoColor=white" alt="Codeforces"/></a>

</div>

<!-- ✂️ разделитель: pulse-dots.svg -->
<div align="center">
  <img src="./assets/dividers/pulse-dots.svg" width="100%" height="10" alt="──────────"/>
</div>

<!-- ═══════════════════ 📊 ДИНАМИЧЕСКАЯ СТАТИСТИКА ═══════════════════ -->
## <img src="https://media.giphy.com/media/3o7TKSjRrfIPjeiVyM/giphy.gif" width="32" height="32"/> GitHub Stats

<!-- ⚠️ ВАЖНО ПРО github-readme-stats: публичный сервер часто упирается
     в rate limit GitHub API (5000 запросов/час на ВСЕХ пользователей).
     Если карточки иногда показывают ошибку — задеплой СВОЙ бесплатный
     инстанс за 2 минуты (кнопка "Deploy" в README проекта) и поменяй
     домен github-readme-stats.vercel.app на свой. -->

<div align="center">

<!-- Главная карточка статистики: звёзды, коммиты, PR, issues, ранг
     count_private=true — считает приватные коммиты (нужен свой инстанс+токен)
     Темы: tokyonight | dracula | radical | onedark | dark | ... (30+) -->
<img src="https://github-readme-stats.vercel.app/api?username=YOUR-USERNAME&show_icons=true&theme=tokyonight&hide_border=true&include_all_commits=true&count_private=true&rank_icon=percentile" height="165" alt="GitHub Stats"/>

<!-- 🔥 Streak — серия дней с коммитами -->
<img src="https://github-readme-streak-stats.herokuapp.com/?user=YOUR-USERNAME&theme=tokyonight&hide_border=true" height="165" alt="Streak"/>

<br/>

<!-- Языки программирования (layout=compact — компактные плитки) -->
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=YOUR-USERNAME&layout=compact&theme=tokyonight&hide_border=true&langs_count=8" height="180" alt="Top Languages"/>

<!-- 🏆 Достижения/трофеи -->
<img src="https://github-profile-trophy.vercel.app/?username=YOUR-USERNAME&theme=onedark&no-frame=true&margin-w=4&row=2&column=4" height="180" alt="Trophies"/>

<br/>

<!-- График активности по дням (за год) -->
<img src="https://github-readme-activity-graph.vercel.app/graph?username=YOUR-USERNAME&theme=tokyo-night&hide_border=true&area=true&custom_title=Contribution%20Graph" width="95%" alt="Activity Graph"/>

</div>

<!-- ═══ 3D-ГРАФИК КОММИТОВ (как на habr-статьях) ═══
     Картинку ГЕНЕРИРУЕТ GitHub Actions раз в сутки (см. файл
     .github/workflows/update-widgets.yml в этом шаблоне).
     Она появляется в ветке профиля по пути profile-3d-contrib/*.svg -->
<div align="center">
  <img src="./profile-3d-contrib/profile-gitblock-green-0.svg" width="95%" alt="3D contribution graph"/>
</div>

<!-- ═══ ЗМЕЙКА 🐍, "съедающая" твои коммиты ═══
     Тоже генерируется Actions-воркфлоу в папку assets/ (snake-dark.svg).
     Картинка-ссылка на gif — она реально анимированная -->
<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="./assets/snake-dark.svg"/>
    <source media="(prefers-color-scheme: light)" srcset="./assets/snake-light.svg"/>
    <img src="./assets/snake-dark.svg" width="95%" alt="Snake animation"/>
  </picture>
</div>

<!-- ✂️ разделитель: divider-classic-blue.gif -->
<div align="center">
  <img src="./assets/dividers/divider-classic-blue.gif" width="100%" alt="──────────"/>
</div>

<!-- ═══════════════════ ⏱ WAKATIME (время за кодом) ═══════════════════ -->
## <img src="https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif" width="32" height="32"/> Coding Time

<!-- 1. Зарегистрируйся на https://wakatime.com (расширение для IDE считает время кодинга)
     2. В настройках WakaTime включи публичный доступ к статистике:
        https://wakatime.com/settings/profile → "Display languages, editors, os publicly"
     3. username= — твой ник на wakatime -->
<div align="center">
  <img src="https://github-readme-stats.vercel.app/api/wakatime?username=YOUR-USERNAME&layout=compact&theme=tokyonight&hide_border=true&langs_count=8" width="55%" alt="WakaTime stats"/>
</div>

<!-- ✂️ разделитель: neon-slide.svg -->
<div align="center">
  <img src="./assets/dividers/neon-slide.svg" width="100%" height="8" alt="──────────"/>
</div>

<!-- ═══════════════════ 🎵 СПОТИФАЙ "ЧТО СЛУШАЮ СЕЙЧАС" ═══════════════════ -->
## <img src="https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif" width="32" height="32"/> Now Playing

<!-- Сервис: https://github.com/kittinan/spotify-github-profile
     1. Открой https://spotify-github-profile.vercel.app/
     2. Нажми LOGIN WITH SPOTIFY, разреши доступ
     3. Скопируй готовую ссылку или свой uid (в URL) и подставь сюда
     Темы: novatorem | default | natemoo-re | compact
     ⚠️ Если трек не играет, виджет покажет последний (show_offline=true) -->
<div align="center">
  <a href="https://open.spotify.com/user/YOUR_SPOTIFY_ID">
    <img src="https://spotify-github-profile.vercel.app/api/view?uid=YOUR_SPOTIFY_ID&cover_image=true&theme=novatorem&show_offline=true&background_color=0d1117&interchange=false&bar_color=53b14f&bar_style=default" width="60%" alt="Spotify now playing"/>
  </a>
</div>

<!-- ✂️ разделитель: wave-dash.svg -->
<div align="center">
  <img src="./assets/dividers/wave-dash.svg" width="100%" height="10" alt="──────────"/>
</div>

<!-- ═══════════════════ 😄 FUN-ВИДЖЕТЫ ═══════════════════ -->
## <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="32" height="32"/> Random Stuff

<div align="center">

<!-- Рандомная цитата (обновляется при каждом заходе) -->
<img src="https://quotes-github-readme.vercel.app/api?type=horizontal&theme=tokyonight&username=YOUR-USERNAME" width="60%" alt="Random quote"/>

<br/><br/>

<!-- Рандомный анекдот про программистов. Если сервис упал — просто удали -->
<img src="https://readme-jokes.vercel.app/api?theme=tokyonight&borderColor=00D4FF" width="60%" alt="Dev joke"/>

</div>

<!-- ✂️ разделитель: rainbow-flow.svg -->
<div align="center">
  <img src="./assets/dividers/rainbow-flow.svg" width="100%" height="8" alt="──────────"/>
</div>

<!-- ═══════════════════ 🎬 ВИДЕО-СЕКЦИЯ ═══════════════════ -->
## <img src="https://media.giphy.com/media/26tn33aiTi1jkl6H6/giphy.gif" width="32" height="32"/> My Projects Showcase

<!-- ⚠️ GitHub НЕ разрешает тег <video> в markdown. Видео вставляется ТОЛЬКО так:
     1. Открой свой README.md в веб-редакторе GitHub (клавиша E или карандаш)
     2. Перетащи mp4/mov файл прямо в окно редактора (drag & drop)
     3. GitHub загрузит файл и вставит строку вида:
        ![Video](https://github.com/YOUR-USERNAME/repo/assets/123456/abc-def)
     4. Вот и всё — на странице README появится видеоплеер.
     Лимиты: до 10 МБ (бесплатный аккаунт), mp4/mov, без автовоспроизведения.
     Раскомментируй пример ниже и замени ссылку на свою: -->

<div align="center">

<!-- ![Video](https://github.com/YOUR-USERNAME/YOUR-USERNAME/assets/000000000/xxxxx-xxxxx) -->

<!-- АЛЬТЕРНАТИВА без лимитов: кликабельный GIF-превью → ссылка на YouTube.
     Тег <video> и плеер YouTube (iframe) в README ЗАПРЕЩЕНЫ, поэтому так: -->
<a href="https://youtube.com/watch?v=ВАШЕ-ВИДЕО">
  <img src="https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg" width="55%" alt="Watch demo video" style="border-radius: 12px;"/>
</a>
<p><sub>👆 Кликни, чтобы посмотреть демо на YouTube</sub></p>

</div>

<!-- ✂️ разделитель: pulse-dots.svg -->
<div align="center">
  <img src="./assets/dividers/pulse-dots.svg" width="100%" height="10" alt="──────────"/>
</div>

<!-- ═══════════════════ 📬 КОНТАКТЫ В РАСКРЫВАШКЕ ═══════════════════ -->
<!-- <details>/<summary> — нативный аккордеон GitHub, единственный
     "интерактив" кроме ссылок. Внутрь можно класть любой markdown -->
<details>
  <summary><b>📬 Contact & Support (click to expand)</b></summary>
  <br/>
  <div align="center">

  | Channel | Link |
  |---------|------|
  | 📧 Email | your@email.com |
  | 💬 Telegram | [@YOUR-USERNAME](https://t.me/YOUR-USERNAME) |
  | 🌐 Website | [your-portfolio.dev](https://your-portfolio.dev) |

  <!-- Кнопка "купить кофе" — тоже интерактивная ссылка -->
  <a href="https://www.buymeacoffee.com/YOUR-USERNAME">
    <img src="https://img.shields.io/badge/Buy%20Me%20a%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black" alt="Buy me a coffee"/>
  </a>

  </div>
</details>

<details>
  <summary><b>⚙️ My GitHub Setup (click to expand)</b></summary>
  <br/>

  - **OS:** Arch Linux btw
  - **Editor:** Neovim + VS Code
  - **Terminal:** Alacritty + tmux + zsh
  - **Shell config:** [dotfiles](https://github.com/YOUR-USERNAME/dotfiles)
  - **Keyboard:** Keychron K8 (mechanical)

</details>

<!-- ✂️ разделитель: divider-classic-blue.gif -->
<div align="center">
  <img src="./assets/dividers/divider-classic-blue.gif" width="100%" alt="──────────"/>
</div>

<div align="center">

<!-- ═══ FOOTER ═══ -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=2,11,30&height=120&section=footer&animation=fadeIn" width="100%" alt="Footer"/>

<!-- Звёздочка-ссылка на профиль + "сделано с любовью" -->
<a href="https://github.com/YOUR-USERNAME">
  <img src="https://img.shields.io/badge/⭐%20Star%20my%20repos!-blueviolet?style=for-the-badge&logo=github&logoColor=white" alt="Star my repos"/>
</a>

<p>
  <sub>Made with ❤️ by <a href="https://github.com/YOUR-USERNAME">YOUR_NAME</a> · Last updated by 🤖 GitHub Actions</sub>
</p>

</div>
